package config;

public class ParcConfig {
	
	public static final int BLOCK_SIZE = 30;
	
	
	public static final int LARGEUR = 1200;
	public static final int HAUTEUR = 900;

		
	public static final int LINE_COUNT = 30;
	public static final int COLUMN_COUNT = 30;
	
	public static final int GAME_SPEED = 7; //e
	
	

}
